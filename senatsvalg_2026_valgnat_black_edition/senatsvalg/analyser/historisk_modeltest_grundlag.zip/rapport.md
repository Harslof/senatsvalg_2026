# Historisk test af senatsprognosens usikkerhed

**Datakilde:** FiveThirtyEight `raw_polls.csv` (2024-datasættet). Kun Sen-G med DEM/REP som to førende kandidater og offentliggjorte målinger før valgdag. Valgår 1998–2022, inklusive særvalg.

## Hvad er testet?

For hvert valg er der rekonstrueret prognoser 28, 14 og 7 dage før valgdagen. Målingerne efter prognosedatoen udelades. Der bruges samme type uvægtet gennemsnit, lineær/kvadratisk trend, 4-ugers minimum for trend, horisontafhængig sigma, 3 pp fælles national usikkerhed og tillæg på 0/2/3 pp lagt til i kvadratur. Sigma estimeres fra **andre valgårs** historiske måling-til-måling-fejl. Et valgår holdes ude ad gangen.

Der er metodiske forskelle fra webmodellens produktion: historiske målinger har kun median-feltdato (ikke start/slut), observationer på samme dag gennemsnitsberegnes, og delstatslokale fejlestimater er udeladt for at forhindre lækage. Derfor er dette en **historisk rekonstruktion**, ikke en bit-for-bit-genkørsel af webapplikationen. Valgdagsresultater bruges udelukkende som facit.

## 90 %-dækning efter model og prognosedato

| Model | Dage før valg | Valg | +0 pp | +2 pp | +3 pp |
|---|---:|---:|---:|---:|---:|
| accelerated | 7 | 357 | 80,7 % | 84,0 % | 86,8 % |
| accelerated | 14 | 336 | 90,2 % | 91,7 % | 92,9 % |
| accelerated | 28 | 276 | 86,2 % | 87,0 % | 87,7 % |
| linear | 7 | 357 | 81,8 % | 84,9 % | 87,4 % |
| linear | 14 | 336 | 91,7 % | 92,6 % | 93,8 % |
| linear | 28 | 276 | 95,7 % | 96,0 % | 96,7 % |

**Mål:** 90 % dækning. Et tal tæt på 90 % er ikke alene nok til at vælge parameter: resultaterne bør også vurderes med logscore, Brier-score og usikkerhed på tværs af valgår. De samme valg indgår på flere prognosedatoer; tabellens rækker er ikke uafhængige.

## Sammenligning af logscore og Brier-score

Begge scores skal være lavere for bedre prædiktiv kvalitet. Logscore måler tæthed for den faktiske valgmargin; Brier-score måler sandsynligheden for demokratisk sejr mod faktisk udfald.

| Model | Dage | Tillæg | Logscore | Brier | 95 %-bootstrapinterval for 90 %-dækning (valgår) |
|---|---:|---:|---:|---:|---|
| accelerated | 7 | 0 | 3.422 | 0.060 | 76,3 %–84,8 % |
| accelerated | 7 | 2 | 3.368 | 0.061 | 79,9 %–88,2 % |
| accelerated | 7 | 3 | 3.332 | 0.062 | 83,7 %–90,5 % |
| accelerated | 14 | 0 | 3.476 | 0.075 | 85,9 %–93,4 % |
| accelerated | 14 | 2 | 3.461 | 0.075 | 89,1 %–94,2 % |
| accelerated | 14 | 3 | 3.453 | 0.076 | 90,4 %–95,3 % |
| accelerated | 28 | 0 | 3.835 | 0.116 | 81,9 %–90,4 % |
| accelerated | 28 | 2 | 3.826 | 0.116 | 82,0 %–91,3 % |
| accelerated | 28 | 3 | 3.816 | 0.116 | 83,0 %–91,8 % |
| linear | 7 | 0 | 3.342 | 0.057 | 77,3 %–86,3 % |
| linear | 7 | 2 | 3.299 | 0.057 | 80,8 %–88,4 % |
| linear | 7 | 3 | 3.274 | 0.058 | 84,1 %–90,6 % |
| linear | 14 | 0 | 3.335 | 0.066 | 88,3 %–94,1 % |
| linear | 14 | 2 | 3.329 | 0.067 | 89,2 %–95,2 % |
| linear | 14 | 3 | 3.331 | 0.067 | 90,5 %–96,2 % |
| linear | 28 | 0 | 3.407 | 0.084 | 92,4 %–98,5 % |
| linear | 28 | 2 | 3.418 | 0.084 | 93,0 %–98,6 % |
| linear | 28 | 3 | 3.432 | 0.085 | 94,3 %–98,9 % |

## Fortolkning

Den historiske test viser, at et universelt tillæg ikke giver ensartet kalibrering ved alle prognosehorisonter. For eksempel er den lineære model 28 dage før valget allerede over 90 % uden tillæg, mens den lineære model 7 dage før valget ligger under 90 % selv med +3 pp. Acceleration har andre fejlprofiler.

Et generelt tillæg på 2 pp kan derfor ikke dokumenteres som universelt optimalt. Resultaterne tyder snarere på, at den nuværende horisontkalibrering, som blev estimeret på senere målinger, ikke automatisk overføres til faktiske valgresultater. **Der er ikke ændret nogen parametre i hjemmesiden.**

## Begrænsninger

- Testen bruger historiske målingsspørgsmål og faktiske valgresultater fra FiveThirtyEight, ikke de faktiske 2026-input.
- Valgår holdes ude ved sigmaestimering, men horisontfaktorerne 0,60 og 1,30 stammer fra tidligere 2026-test og er ikke estimeret på en historisk træningsfold.
- En fælles national fejl på 3 pp er indregnet i hver delstats marginale interval, men den fulde fælles, korrelerede fordeling af mandatresultater er ikke valideret her.
- Data omfatter primært valg, hvor både D og R er blandt de to øverste kandidater. Ikke dækkende for alle særlige valgsituationer eller delstater uden målinger.
- Historiske vælgere, målemetoder og partilandskab er ikke nødvendigvis repræsentative for 2026.
- Der er ikke foretaget separat genkalibrering af huseffekter eller systematiske institutkorrektioner.

## Reproducerbarhed

`run.py` udfører historisk genberegning; `forecasts.csv` indeholder hver observation og scenarie, `summary.csv` indeholder aggregerede mål, `bootstrap.csv` viser usikkerheden ved genudtræk af hele valgår.