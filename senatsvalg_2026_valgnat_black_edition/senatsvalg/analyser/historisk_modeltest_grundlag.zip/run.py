import pandas as pd,numpy as np, math,json
from pathlib import Path
from scipy.stats import norm
ROOT=Path(__file__).parent
raw=pd.read_csv('/mnt/data/raw_polls.csv',low_memory=False)
d=raw[(raw.type_simple=='Sen-G')&(raw.cand1_party=='DEM')&(raw.cand2_party=='REP')].copy()
for c in ['margin_poll','margin_actual']:d[c]=pd.to_numeric(d[c],errors='coerce')
d['year']=d['cycle'];d['date']=pd.to_datetime(d.polldate,errors='coerce');d['election']=pd.to_datetime(d.electiondate,errors='coerce');d=d.dropna(subset=['date','election','margin_poll','margin_actual'])
d=d[(d.date<=d.election)&((d.election-d.date).dt.days<=200)].drop_duplicates(['race','poll_id','question_id'])
# Separate year election, race. All observations before cutoff; poll midpoint proxy supplied by 538.
rows=[]; errors=[]
for (year,race),g in d.groupby(['year','race']):
 g=g.sort_values('date'); target=float(g.margin_actual.median()); election=g.election.iloc[0]
 # Build rolling later-poll errors for estimating sigma from prior years, one future observation per race-date
 pts=g.groupby('date',as_index=False).agg(y=('margin_poll','mean'), n=('margin_poll','size'))
 dates=pts.date.to_numpy(dtype='datetime64[ns]');ys=pts.y.to_numpy(float)
 def snapshot(idx, model, horizon):
  t=(dates[idx]-dates[idx].max())/np.timedelta64(1,'D')/7
  y=ys[idx];n=len(y)
  margin=float(y.mean());trend=acc=0.;hastrend=hasacc=False
  if n>=2 and -t.min()>=4:
   try:
    a=np.linalg.lstsq(np.vander(t,2,increasing=True),y,rcond=None)[0];trend=float(a[1]);hastrend=True
    if n>=3:
     b=np.linalg.lstsq(np.vander(t,3,increasing=True),y,rcond=None)[0];acc=float(2*b[2]);hasacc=True
   except np.linalg.LinAlgError:pass
  return float(np.clip(margin+trend*horizon+(0.5*acc*horizon*horizon if model=='accelerated' else 0),-35,35)),n,hastrend,hasacc
 for j in range(2,len(pts)):
  h=(dates[j]-dates[j-1])/np.timedelta64(1,'D')/7
  if not (.15<=h<=20):continue
  for model in ['linear','accelerated']:
   pred,n,ht,ha=snapshot(np.arange(j),model,h)
   if not (ht if model=='linear' else ha):continue
   errors.append(dict(year=int(year),race=race,model=model,horizon=float(h),error=float(np.clip(ys[j]-pred,-35,35))))
 for days in [7,14,28]:
  origin=election-pd.Timedelta(days=days)
  ix=np.where(dates<=np.datetime64(origin))[0]
  if len(ix)<2:continue
  last=pd.Timestamp(dates[ix[-1]])
  h=(election-last).days/7
  if h>20:continue
  for model in ['linear','accelerated']:
   pred,n,ht,ha=snapshot(ix,model,h)
   rows.append(dict(year=int(year),race=race,model=model,days=days,n=n,horizon=h,forecast=pred,actual=target,error=target-pred,hasTrend=ht,hasAccel=ha))
print('rolling errors',len(errors),'forecasts',len(rows),flush=True)
e=pd.DataFrame(errors);f=pd.DataFrame(rows)
# Strict held-out year calibration: other years only. Per-state local tests excluded (no future leakage).
# Match estimateSigma() kernel, pooled weighting by inverse sqrt of number of errors per race, horizon kernel, extrapolation, minimum floor.
allresults=[]
for (year,model),ff in f.groupby(['year','model']):
 train=e[(e.year!=year)&(e.model==model)]
 if train.empty:continue
 counts=train.race.value_counts();train=train.copy();train['w0']=train.race.map(lambda x:1/math.sqrt(counts[x]))
 H=train.horizon.to_numpy();E=train.error.to_numpy();W0=train.w0.to_numpy()
 for row in ff.itertuples():
  w=np.exp(-np.abs(H-row.horizon)/6)*W0;sw=w.sum();pooled=math.sqrt(float(np.sum(w*E*E)/sw)) if sw else 6
  observed=float(np.sum(w*H)/sw) if sw else 2
  extrap=math.sqrt((1+max(0,row.horizon)/10)/(1+observed/10))
  sparse=3.5 if row.n<=1 else 2.5 if row.n<=3 else 1.5 if row.n<=5 else 0
  factor=.60 if row.horizon<=2 else 1.30
  sigma=float(np.clip(math.sqrt(max(3.5**2,pooled**2*extrap**2)+sparse**2)*factor,3.5,35))
  # no local historical errors: these are held out, so conservatively pooled
  for extra in [0,2,3]:
   # The 3pp shared swing is included in marginal uncertainty, but NOT added again in local residual.
   marginal=math.hypot(sigma,3,extra)
   z=abs(row.error)/marginal
   allresults.append(dict(year=year,race=row.race,model=model,days=row.days,horizon=row.horizon,n=row.n,forecast=row.forecast,actual=row.actual,error=row.error,sigma=sigma,extra=extra,sd=marginal,p=norm.cdf(row.forecast/marginal),cover50=z<=norm.ppf(.75),cover80=z<=norm.ppf(.90),cover90=z<=norm.ppf(.95),cover95=z<=norm.ppf(.975),logscore=-norm.logpdf(row.actual,loc=row.forecast,scale=marginal)))
a=pd.DataFrame(allresults)
a.to_csv(ROOT/'forecasts.csv',index=False)
summary=[]
for (model,days,extra),g in a.groupby(['model','days','extra']):
 summary.append(dict(model=model,days=int(days),extra=int(extra),n=len(g),years=g.year.nunique(),races=g.race.nunique(),rmse=float(np.sqrt(np.mean(g.error**2))),mae=float(g.error.abs().mean()),sigma=float(g.sd.mean()),cover50=float(g.cover50.mean()),cover80=float(g.cover80.mean()),cover90=float(g.cover90.mean()),cover95=float(g.cover95.mean()),logscore=float(g.logscore.mean()),brier=float(np.mean((g.p-(g.actual>0).astype(float))**2))))
sumdf=pd.DataFrame(summary);sumdf.to_csv(ROOT/'summary.csv',index=False)
print(sumdf[['model','days','extra','n','years','cover90','logscore','brier']].to_string(index=False),flush=True)
# year-block bootstrap for 90% interval to acknowledge within-year correlation
rng=np.random.default_rng(42);boot=[]
for (model,days,extra),g in a.groupby(['model','days','extra']):
 years=g.year.unique();vals=[]
 for i in range(1200):
  selected=rng.choice(years,len(years),replace=True)
  vals.append(np.mean(np.concatenate([g.loc[g.year==yr,'cover90'].to_numpy() for yr in selected])))
 boot.append(dict(model=model,days=int(days),extra=int(extra),lo=float(np.quantile(vals,.025)),hi=float(np.quantile(vals,.975))))
pd.DataFrame(boot).to_csv(ROOT/'bootstrap.csv',index=False)
# paired per-year logscore difference (2 vs 0, 3 vs 0)
print('years',sorted(a.year.unique()),flush=True)
